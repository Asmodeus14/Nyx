/mnt/c/CODE/Nyx/target/x86_64-nyx/release/nyx-init: /mnt/c/CODE/Nyx/nyx-api/src/lib.rs /mnt/c/CODE/Nyx/nyx-init/src/main.rs
